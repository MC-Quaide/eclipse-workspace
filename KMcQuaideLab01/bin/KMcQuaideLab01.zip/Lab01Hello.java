//KMcQuaide
//An initial trip through Eclipse
//23 January 2021

public class Lab01Hello {

	public static void main(String[] args) {
		System.out.println("Hello, my name is Kyle!");
		System.out.printf("%S%n",  "glad to be in this class");
		System.out.print("Already better than 2020!");
		
	}

}
